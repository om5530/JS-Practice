// Write a function which counts vowels in a string
