// Write a function which checks if string is a palindrome
