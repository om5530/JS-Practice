// Write an example of fetching data using fetch API.
