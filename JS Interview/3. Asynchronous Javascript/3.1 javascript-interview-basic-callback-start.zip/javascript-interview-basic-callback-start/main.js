// Write an asynchronous function which executes callback after finishing it's asynchronous task
// What problem callbacks solve?
