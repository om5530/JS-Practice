// Write an example of fetching data with XMLHttpRequest.
