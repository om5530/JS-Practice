// Design a shallow comparison function
