// Design a memoization function which adds 10 to provided value and take it from cache if it was already calculated.
//
