// Design a deep comparison function
